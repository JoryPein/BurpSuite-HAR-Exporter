## bpi2har

bpi2har is a Python-based tool for converting saved burpsuite http items to the HTTP Archive (HAR) format.

## CLI usage

```shell
bpi2har exported.xml
```
