# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['bpi2har']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['bpi2har = bpi2har.cli:app']}

setup_kwargs = {
    'name': 'bpi2har',
    'version': '0.1.0',
    'description': '',
    'long_description': '## bpi2har\n\nbpi2har is a Python-based tool for converting saved burpsuite http items to the HTTP Archive (HAR) format.\n\n## CLI usage\n\n```shell\nbpi2har exported.xml\n```\n',
    'author': 'Gideon Pein',
    'author_email': "none@none.com'",
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
